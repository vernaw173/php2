<?php 
if ($_POST) { 
  $message = '';
  if(isset($_POST['name']) && !empty($_POST['name'])){
    $name = htmlspecialchars($_POST['name']);
    $message .= 'Имя: '.$name;
  }
  if(isset($_POST['phone']) && !empty($_POST['phone'])){
    $phone = htmlspecialchars($_POST['phone']);
    $message .= 'Телефон: '.$phone;
  }
  if(isset($_POST['massege']) && !empty($_POST['massege'])){
    $text = htmlspecialchars($_POST['massege']);
    $message .= 'Доп. информация: '.$text;
  }

  $to  = '9009971@mail.ru';
  $subject = "Заявка";

  $headers = 'From: 9009971@mail.ru' . "\r\n";
  $headers .= 'Reply-To: 9009971@mail.ru' . "\r\n";
  $headers .= 'X-Mailer: PHP/' . phpversion();
    
  $status = mail($to, $subject, $message, $headers); 
    
  $json = array();
  if($status){
    $json['status'] = 'success';
  }else{
    $json['status'] = 'error';
  }
  
  echo json_encode($json); 
} else { 
  echo 'У вас нет прав для входа на эту страницу!'; 
}
?>