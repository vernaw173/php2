$(document).ready(function(){
	$('.button').click(function(e){ 
		e.preventDefault(); 
         $('.overlay').fadeIn('fast',function(){ 
             $('.nonebox').animate({'top':'40%'},500); 
         });
     });

     $('.box-close.one').click(function(e){ // êëèêàåì ïî ýëåìåíòó êîòîðûé âñ¸ ýòî áóäåò çàêðûâàòü
      e.preventDefault(); 
         $('.nonebox').animate({'top':'-1100px'},500,function(){ // óáèðàåì íàø áëîê
             $('.overlay').fadeOut('fast'); // è òåïåðü óáèðàåì îâåðëýé
         });

     });
     $('.buttonp').click(function(e){ 
		e.preventDefault(); 
         $('.overlay1').fadeIn('fast',function(){ 
             $('.nonebox1').animate({'top':'50%'},500); 
         });
     });

     $('.box-close1.one').click(function(e){ // êëèêàåì ïî ýëåìåíòó êîòîðûé âñ¸ ýòî áóäåò çàêðûâàòü
      e.preventDefault(); 
         $('.nonebox1').animate({'top':'-1100px'},500,function(){ // óáèðàåì íàø áëîê
             $('.overlay1').fadeOut('fast'); // è òåïåðü óáèðàåì îâåðëýé
         });

     });
     $(".tel_phone").mask("+7 (999) 999-99-99");
	 
	 
	 
	 $('form').submit(function(e){
		e.preventDefault();
		var flag = 1;
		var form = $(this).attr('id');
		var name = $(this).find('input[name="name"]');
		var tel = $(this).find('input[name="phone"]');
		if (name.val() == "") { flag = 0; name.css('border-color','red'); } else { name.css('border-color','#e1e1e1'); }
		if (tel.val() == "") { flag = 0; tel.css('border-color','red'); } else { tel.css('border-color','#e1e1e1'); }
		if (flag) {
			var m_method=$(this).attr('method');
			var m_action=$(this).attr('action');
			var m_data=$(this).serialize();
			$.ajax({
				type: m_method,
				url: m_action,
				data: m_data,
				dataType: 'json',
				success: function(result){
					if(result['status'] == 'success'){
						$('#'+form)[0].reset();
						//$('#'+form).html("<p class='thn'>Спасибо! В ближайшее время наш менеджер свяжется с вами.</p>");
						$('#'+form).append('<div class="alert alert-success mailSuccess" role="alert">Спасибо! В ближайшее время наш менеджер свяжется с вами.</div>');
						setTimeout(function(){
							$('#'+form+' .mailSuccess').hide();
						}, 3000);
					}
				},
				error: function (xhr, ajaxOptions, thrownError) { 
				  console.log(xhr.status); 
				  console.log(thrownError);
				},
			});
			
		}
	});
	 

});